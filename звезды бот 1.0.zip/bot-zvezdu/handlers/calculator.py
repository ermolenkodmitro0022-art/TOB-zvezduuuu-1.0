"""
Калькулятор Stars <-> UAH.
"""

from __future__ import annotations
import logging

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.queries import get_user, get_all_settings
from locales.texts import t
from keyboards.client_kb import calc_direction_keyboard, back_to_menu_keyboard
from states.fsm import CalculatorFSM
from utils.helpers import calculate_price, calculate_stars_from_uah, get_mode_display

router = Router()
logger = logging.getLogger(__name__)


async def _get_lang(user_id: int) -> str:
    user = await get_user(user_id)
    return user["language"] if user and user["language"] else "ua"


@router.callback_query(F.data.startswith("calc:"), CalculatorFSM.choose_direction)
async def callback_calc_direction(callback: CallbackQuery, state: FSMContext) -> None:
    """Выбор направления конвертации."""
    try:
        lang = await _get_lang(callback.from_user.id)
        direction = callback.data.split(":")[1]

        if direction == "stars_to_uah":
            await callback.message.edit_text(
                t("calc_enter_stars", lang),
                parse_mode="HTML",
            )
            await state.update_data(
                direction="stars_to_uah",
                last_bot_msg=callback.message.message_id,
            )
        else:
            await callback.message.edit_text(
                t("calc_enter_uah", lang),
                parse_mode="HTML",
            )
            await state.update_data(
                direction="uah_to_stars",
                last_bot_msg=callback.message.message_id,
            )

        await state.set_state(CalculatorFSM.enter_amount)
        await callback.answer()
    except Exception as e:
        logger.error(f"Error in callback_calc_direction: {e}", exc_info=True)


@router.message(CalculatorFSM.enter_amount)
async def process_calc_amount(message: Message, state: FSMContext) -> None:
    """Обработка ввода суммы для калькулятора."""
    try:
        lang = await _get_lang(message.from_user.id)
        data = await state.get_data()
        direction = data.get("direction", "stars_to_uah")

        # Удаляем предыдущее и сообщение пользователя
        prev_id = data.get("last_bot_msg")
        if prev_id:
            try:
                await message.bot.delete_message(message.chat.id, prev_id)
            except Exception:
                pass
        try:
            await message.delete()
        except Exception:
            pass

        text = message.text.strip().replace(",", ".") if message.text else ""
        try:
            amount = float(text)
            if amount <= 0:
                raise ValueError
        except (ValueError, TypeError):
            msg = await message.answer(
                t("calc_invalid", lang),
                parse_mode="HTML",
            )
            await state.update_data(last_bot_msg=msg.message_id)
            return

        settings = await get_all_settings()
        mode = settings.get("active_mode", "standard")
        price_100 = float(settings.get(
            "price_100_dump" if mode == "dump" else "price_100_standard",
            "73.0" if mode == "dump" else "80.0"
        ))

        mode_display = get_mode_display(mode, lang)

        if direction == "stars_to_uah":
            stars = int(amount)
            price = calculate_price(stars, price_100)
            result_text = t("calc_result_stars_to_uah", lang,
                            stars=stars,
                            price=str(price))
        else:
            uah = amount
            stars = calculate_stars_from_uah(uah, price_100)
            result_text = t("calc_result_uah_to_stars", lang,
                            uah=f"{uah:.0f}" if uah.is_integer() else f"{uah:.2f}",
                            stars=stars)

        msg = await message.answer(
            result_text,
            reply_markup=back_to_menu_keyboard(lang),
            parse_mode="HTML",
        )
        await state.clear()
    except Exception as e:
        logger.error(f"Error in process_calc_amount: {e}", exc_info=True)
        await state.clear()
