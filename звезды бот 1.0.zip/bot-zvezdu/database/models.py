"""
Схема базы данных — создание таблиц при первом запуске.
"""

import aiosqlite
from config import DB_PATH


async def init_db() -> None:
    """Создаёт все таблицы, если они ещё не существуют."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT DEFAULT '',
                first_name  TEXT DEFAULT '',
                language    TEXT DEFAULT '',
                is_banned   INTEGER DEFAULT 0,
                created_at  TEXT DEFAULT (datetime('now'))
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id             INTEGER NOT NULL,
                stars_amount        INTEGER NOT NULL,
                price_uah           REAL NOT NULL,
                recipient_username  TEXT NOT NULL DEFAULT '',
                recipient_for_self  INTEGER DEFAULT 1,
                status              TEXT NOT NULL DEFAULT 'new',
                screenshot_file_id  TEXT DEFAULT '',
                admin_message_id    INTEGER DEFAULT 0,
                cancel_reason       TEXT DEFAULT '',
                created_at          TEXT DEFAULT (datetime('now')),
                updated_at          TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id   INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                text       TEXT NOT NULL,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (order_id) REFERENCES orders(id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        # Значения по умолчанию для настроек
        defaults = {
            "ton_rate": "250.0",
            "markup_dump": "5.0",
            "markup_standard": "15.0",
            "active_mode": "standard",   # "dump" или "standard"
        }
        for key, value in defaults.items():
            await db.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value),
            )

        await db.commit()
