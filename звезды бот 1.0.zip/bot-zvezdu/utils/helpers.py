"""
Вспомогательные функции: расчёт цен, форматирование.
"""

from __future__ import annotations
import re


def calculate_price(stars: int, price_100: float) -> int:
    """
    Формула: (stars / 100.0) * price_100.
    Возвращает цену в гривнах, округлённую до целого числа (без копеек).
    """
    return int(round((stars / 100.0) * price_100))


def calculate_stars_from_uah(uah: float, price_100: float) -> int:
    """
    Обратная формула: сколько Stars можно купить за uah гривен.
    stars = (uah / price_100) * 100
    """
    if price_100 <= 0:
        return 0
    raw = (uah / price_100) * 100
    return max(0, int(round(raw)))


def validate_username(text: str) -> str | None:
    """
    Валидирует username. Возвращает очищенный @username или None.
    Отклоняет ссылки на каналы/чаты (t.me/+... , t.me/joinchat, и т.д.).
    """
    text = text.strip()

    # Отклоняем ссылки на каналы/группы
    reject_patterns = [
        r"t\.me/\+",              # Инвайт-ссылки
        r"t\.me/joinchat",        # Старые инвайт-ссылки
        r"telegram\.me/joinchat",
        r"https?://",             # Любые ссылки
    ]
    for pattern in reject_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return None

    # Извлекаем username из текста
    # Допустимый формат: @username или просто username
    match = re.match(r"^@?([a-zA-Z][a-zA-Z0-9_]{4,31})$", text)
    if match:
        return f"@{match.group(1)}"
    return None


def get_status_emoji(status: str) -> str:
    """Возвращает эмодзи для статуса заказа."""
    return {
        "new": "⏳",
        "paid": "💸",
        "processing": "🔄",
        "delivered": "✅",
        "cancelled": "❌",
    }.get(status, "❓")


def get_mode_display(mode: str, lang: str) -> str:
    """Возвращает отображаемое название режима."""
    modes = {
        "dump": {"ua": "🔥 Демпінг", "ru": "🔥 Демпинг"},
        "standard": {"ua": "🚀 Стандарт", "ru": "🚀 Стандарт"},
    }
    return modes.get(mode, {}).get(lang, mode)
